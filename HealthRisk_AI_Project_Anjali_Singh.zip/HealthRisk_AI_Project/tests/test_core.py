import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import numpy as np
from src.healthrisk.data import make_synthetic_patient_data
from src.healthrisk.insurance import premium, risk_score, mlr
from src.healthrisk.hospital import probability_default, expected_loss, credit_grade
from src.healthrisk.pharma import rnpv, trial_signal
from src.healthrisk.epidemiology import sir, r0
from src.healthrisk.simulation import run_simulation

def test_synthetic_data():
    df=make_synthetic_patient_data(100)
    assert len(df)==100
    assert df.isna().sum().sum()==0

def test_insurance():
    assert premium(1000)>1000
    assert 0<risk_score(60,3,8,45,1,.8)<1
    assert mlr(80,100)==.8

def test_hospital():
    pd=probability_default(.02,2,90,.17,3,-.04,6)
    assert 0<pd<1
    assert expected_loss(pd,.5,1e6)>0
    assert credit_grade(pd) in {"A","BBB+","BBB-","BB","B"}

def test_pharma():
    assert rnpv(.5,1e9,2,.1)>0
    assert trial_signal(1.1,.08,10)=="POSITIVE"

def test_sir():
    df=sir(.35,.14,days=30)
    assert len(df)==30
    assert abs(r0(.35,.14)-2.5)<1e-9
    assert np.all(df[["S","I","R"]].sum(axis=1) > 0)

def test_simulation():
    sim,player,ai=run_simulation()
    assert len(sim)==40
    assert player.capital>0 and ai.capital>0
    assert sim.score.iloc[-1]>=0
