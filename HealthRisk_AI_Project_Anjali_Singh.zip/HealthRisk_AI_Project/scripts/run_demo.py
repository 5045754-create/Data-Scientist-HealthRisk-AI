import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.healthrisk.pipeline import run
from src.healthrisk.data import make_hospital_data, make_pharma_pipeline
from src.healthrisk.hospital import probability_default, credit_grade, expected_loss
from src.healthrisk.pharma import analyse_pipeline
from src.healthrisk.epidemiology import sir, r0
from src.healthrisk.simulation import run_simulation

def main():
    result=run()
    print("=== HealthRisk AI Demo ===")
    print("Patient model:", result)
    hospitals=make_hospital_data()
    for _,r in hospitals.iterrows():
        pd=probability_default(r.operating_margin,r.dscr,r.cash_days,r.readmission,
                               r.hca_hps,r.cmi_trend,r.ed_boarding)
        print(r.hospital, "PD=",round(pd,4),"grade=",credit_grade(pd),
              "EL=$",round(expected_loss(pd,.45,r.revenue_m*1e6)))
    pharma=analyse_pipeline(make_pharma_pipeline())
    print(pharma[["company","rnpv","pipeline_to_market_cap","signal"]].to_string(index=False))
    epi=sir(beta=.35,gamma=.14,days=180)
    print("R0:",round(r0(.35,.14),2),"Peak infected:",int(epi.I.max()))
    sim,_,_=run_simulation()
    sim.to_csv("data/processed/master_mode_run.csv",index=False)
    print("Final player capital:",round(sim.player_capital.iloc[-1]))
    print("Final AI capital:",round(sim.ai_capital.iloc[-1]))
    print("Final score:",round(sim.score.iloc[-1],1))

if __name__=="__main__":
    main()
