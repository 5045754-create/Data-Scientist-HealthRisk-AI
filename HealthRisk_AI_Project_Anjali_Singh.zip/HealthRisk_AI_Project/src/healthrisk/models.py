import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, r2_score, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split

FEATURES=["age","chronic_conditions","hba1c","egfr","admissions","ed_visits",
          "medication_count","adherence","prior_cost"]

def train_risk_models(df, seed=42):
    X=df[FEATURES]
    y=df["readmission_30d"]
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,stratify=y,random_state=seed)
    clf=GradientBoostingClassifier(random_state=seed)
    clf.fit(Xtr,ytr)
    p=clf.predict_proba(Xte)[:,1]
    metrics={
        "auroc":float(roc_auc_score(yte,p)),
        "auprc":float(average_precision_score(yte,p)),
        "brier":float(brier_score_loss(yte,p))
    }
    return clf, metrics

def train_cost_model(df, seed=42):
    X=df[FEATURES]
    y=np.log1p(df["total_cost"])
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=seed)
    reg=GradientBoostingRegressor(random_state=seed)
    reg.fit(Xtr,ytr)
    pred=np.expm1(reg.predict(Xte))
    actual=np.expm1(yte)
    return reg, {"r2_log":float(r2_score(yte, np.log1p(pred))),
                  "mape":float(mean_absolute_percentage_error(actual,pred))}

def stacking_meta(predictions, target):
    X=np.column_stack(predictions)
    meta=Ridge(alpha=1.0).fit(X,target)
    return meta

def feature_contributions(model, row):
    vals=row.to_numpy(dtype=float)
    baseline=np.repeat(row.mean(),len(vals))
    pred=model.predict(pd.DataFrame([vals],columns=row.index))[0]
    contrib=[]
    for i,c in enumerate(row.index):
        x=vals.copy(); x[i]=baseline[i]
        new=model.predict(pd.DataFrame([x],columns=row.index))[0]
        contrib.append((c,float(pred-new)))
    return sorted(contrib,key=lambda z:abs(z[1]),reverse=True)
