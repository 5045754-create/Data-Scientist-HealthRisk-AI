import numpy as np

def clinical_quality_score(readmission, hca_hps, cmi_trend, ed_boarding):
    # Higher is worse. Bounded 0-1.
    x = (3.2*max(0, readmission-.15) + .08*max(0,4-hca_hps) +
         1.8*max(0,-cmi_trend) + .03*max(0,ed_boarding-5))
    return float(np.clip(x, 0, 1))

def probability_default(operating_margin, dscr, cash_days, readmission,
                         hca_hps, cmi_trend, ed_boarding):
    q = clinical_quality_score(readmission,hca_hps,cmi_trend,ed_boarding)
    financial = (0.03 - operating_margin)*10 + max(0,2-dscr)*.55 + max(0,60-cash_days)/120
    logit = -3.8 + financial + 2.5*q
    return float(1/(1+np.exp(-logit)))

def expected_loss(pd, lgd, ead):
    return pd*lgd*ead

def credit_grade(pd):
    if pd < .01: return "A"
    if pd < .02: return "BBB+"
    if pd < .035: return "BBB-"
    if pd < .06: return "BB"
    return "B"
