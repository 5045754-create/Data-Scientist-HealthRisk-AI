from dataclasses import dataclass, field
import numpy as np
import pandas as pd

SCENARIOS = [
    ("Pandemic outbreak", {"insurance":-.08,"hospital":-.10,"pharma":.12,"credit":.06}),
    ("Drug trial failure", {"insurance":0,"hospital":-.01,"pharma":-.20,"credit":.01}),
    ("Regulatory approval wave", {"insurance":.01,"hospital":.01,"pharma":.16,"credit":-.01}),
    ("Hospital capacity crisis", {"insurance":-.04,"hospital":-.14,"pharma":.05,"credit":.08}),
    ("Emerging disease", {"insurance":-.05,"hospital":-.05,"pharma":.08,"credit":.04}),
    ("Reimbursement cut", {"insurance":-.02,"hospital":-.08,"pharma":-.02,"credit":.05}),
    ("Hospital merger", {"insurance":.01,"hospital":.04,"pharma":0,"credit":-.02}),
    ("Safety signal", {"insurance":-.01,"hospital":0,"pharma":-.12,"credit":.01}),
    ("Patent cliff", {"insurance":0,"hospital":0,"pharma":-.15,"credit":0}),
    ("Normal quarter", {"insurance":.01,"hospital":.012,"pharma":.018,"credit":.008}),
]

@dataclass
class Portfolio:
    capital: float=500_000_000
    insurance: float=.30
    hospital: float=.25
    pharma: float=.30
    credit: float=.15
    score: float=0
    history: list=field(default_factory=list)

    def weights(self):
        return np.array([self.insurance,self.hospital,self.pharma,self.credit])

    def rebalance(self, w):
        w=np.maximum(np.asarray(w,float),0)
        w=w/w.sum()
        self.insurance,self.hospital,self.pharma,self.credit=w

def ai_action(event, portfolio):
    impact=event[1]
    w=portfolio.weights()
    # AI reduces exposure to the most negative shocked bucket and reallocates to
    # the strongest bucket, with conservative bounds.
    worst=int(np.argmin([impact["insurance"],impact["hospital"],impact["pharma"],impact["credit"]]))
    best=int(np.argmax([impact["insurance"],impact["hospital"],impact["pharma"],impact["credit"]]))
    w[worst]*=.75
    transfer=portfolio.weights()[worst]-w[worst]
    w[best]+=transfer
    return w/w.sum()

def run_simulation(seed=42, quarters=40, starting_capital=500_000_000, player_policy=None):
    rng=np.random.default_rng(seed)
    player=Portfolio(capital=starting_capital)
    ai=Portfolio(capital=starting_capital)
    rows=[]
    for q in range(1,quarters+1):
        event=SCENARIOS[rng.integers(0,len(SCENARIOS))]
        name, impact=event
        ai.rebalance(ai_action(event,ai))
        if player_policy:
            player.rebalance(player_policy(event, player))
        else:
            player.rebalance(player.weights())
        noise=rng.normal(0,.01,4)
        p_ret=float(np.dot(player.weights(),np.array(list(impact.values()))+noise))
        a_ret=float(np.dot(ai.weights(),np.array(list(impact.values()))+noise))
        player.capital*=1+p_ret
        ai.capital*=1+a_ret
        # scoring rewards return, resilience and relative performance
        player.score += max(0,50+300*p_ret+50*(p_ret-a_ret))
        rows.append({"quarter":q,"event":name,"player_capital":player.capital,
                     "ai_capital":ai.capital,"player_return":p_ret,
                     "ai_return":a_ret,"score":player.score})
    return pd.DataFrame(rows), player, ai
