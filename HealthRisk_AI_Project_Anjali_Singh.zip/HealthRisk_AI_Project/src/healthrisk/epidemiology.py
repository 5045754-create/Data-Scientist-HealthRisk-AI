import numpy as np
import pandas as pd

def sir(beta=.35, gamma=.14, population=1_000_000, initial_infected=100,
        days=180):
    s, i, r = population-initial_infected, initial_infected, 0.0
    rows = []
    for day in range(days):
        rows.append((day, s, i, r))
        new_inf = beta*s*i/population
        new_rec = gamma*i
        s -= new_inf
        i += new_inf-new_rec
        r += new_rec
    return pd.DataFrame(rows, columns=["day","S","I","R"])

def r0(beta, gamma):
    return beta/gamma

def pandemic_financial_shock(peak_infected_share, base_claims,
                             elective_revenue_share=.25):
    claims_multiplier = 1 + 2.0*peak_infected_share
    hospital_revenue_multiplier = 1 - elective_revenue_share*min(1, 3*peak_infected_share)
    return {
        "claims": base_claims*claims_multiplier,
        "hospital_revenue_multiplier": hospital_revenue_multiplier
    }
