"""Cross-domain prediction fusion."""
import numpy as np
from sklearn.linear_model import Ridge

class HealthRiskEnsemble:
    def __init__(self, alpha=1.0):
        self.model=Ridge(alpha=alpha)
    def fit(self, component_predictions, target):
        X=np.column_stack(component_predictions)
        self.model.fit(X,target)
        return self
    def predict(self, component_predictions):
        return self.model.predict(np.column_stack(component_predictions))
