import numpy as np

def expected_claim_cost(frequency, severity):
    return np.asarray(frequency) * np.asarray(severity)

def premium(expected_claims, risk_margin=.08, admin_loading=.06, profit_margin=.05):
    base = np.asarray(expected_claims)
    return base * (1+risk_margin+admin_loading+profit_margin)

def risk_score(age, chronic, hba1c, egfr, admissions, adherence):
    raw = (-3.4 + .022*age + .34*chronic + .16*admissions +
           .18*(hba1c-7) - .012*(egfr-60) + .25*(1-adherence))
    return float(1/(1+np.exp(-raw)))

def mlr(claims, premium_earned):
    return claims/premium_earned if premium_earned else np.nan

def chain_ladder(triangle):
    factors=[]
    for j in range(triangle.shape[1]-1):
        num=np.nansum(triangle[:,j+1])
        den=np.nansum(triangle[:,j])
        factors.append(num/den if den else 1)
    ult=[]
    for i in range(triangle.shape[0]):
        vals=triangle[i,:]
        last=np.where(~np.isnan(vals))[0][-1]
        val=vals[last]
        for f in factors[last:]:
            val*=f
        ult.append(val)
    return np.array(ult)
