"""Simple actuarial reserve helpers."""
import numpy as np

def bornhuetter_ferguson(earned_premium, expected_loss_ratio, reported,
                         percent_reported):
    expected_ultimate=earned_premium*expected_loss_ratio
    unreported=expected_ultimate*(1-percent_reported)
    return np.maximum(0, unreported), expected_ultimate

def reserve_accuracy(actual_ibnr,predicted_ibnr):
    if actual_ibnr==0: return 0.0
    return abs(actual_ibnr/predicted_ibnr-1)
