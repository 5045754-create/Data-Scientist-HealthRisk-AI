"""Lightweight clinical-text baseline.

Production extension: replace TF-IDF with Bio_ClinicalBERT/PubMedBERT after
approved clinical-note access. The API is intentionally model-agnostic.
"""
import re
from collections import Counter

MEDICATION_TERMS={"metformin","lisinopril","atorvastatin","amlodipine","insulin"}
CONDITION_TERMS={"diabetes","hypertension","ckd","cancer","copd","heart failure"}

def extract_entities(text):
    tokens=re.findall(r"[A-Za-z][A-Za-z-]+", text.lower())
    meds=[t for t in tokens if t in MEDICATION_TERMS]
    conditions=[t for t in tokens if t in CONDITION_TERMS]
    return {"medications":sorted(set(meds)),
            "conditions":sorted(set(conditions))}

def complexity_score(text):
    e=extract_entities(text)
    return min(1.0, .08*len(e["medications"])+.12*len(e["conditions"])
               +.002*len(text.split()))

def term_frequency(text):
    return Counter(re.findall(r"[a-z]+", text.lower()))
