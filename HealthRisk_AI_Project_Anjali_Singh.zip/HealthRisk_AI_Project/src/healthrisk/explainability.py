def counterfactual_risk(model, row, changes, threshold):
    candidate=row.copy()
    candidate.update(changes)
    p=float(model.predict_proba(candidate.to_frame().T)[:,1][0])
    return {"probability":p,"threshold":threshold,"passes":p<threshold,
            "changes":changes}

def simple_local_explanation(model, row):
    base=float(model.predict_proba(row.to_frame().T)[:,1][0])
    out=[]
    for c in row.index:
        modified=row.copy()
        if modified[c] != 0:
            modified[c]=0
        new=float(model.predict_proba(modified.to_frame().T)[:,1][0])
        out.append({"feature":c,"baseline":base,"without_feature":new,
                    "delta":base-new})
    return sorted(out,key=lambda x:abs(x["delta"]),reverse=True)
