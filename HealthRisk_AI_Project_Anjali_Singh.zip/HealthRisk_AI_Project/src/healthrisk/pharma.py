import numpy as np
import pandas as pd

def rnpv(success_prob, cashflow, years, discount_rate):
    return success_prob*cashflow/((1+discount_rate)**years)

def trial_signal(enrollment_velocity, dropout_rate, patent_years):
    score = 0
    score += 1 if enrollment_velocity >= 1 else -1
    score += 1 if dropout_rate <= .12 else -1
    score += 1 if patent_years >= 7 else -1
    return "POSITIVE" if score >= 2 else ("NEGATIVE" if score <= -2 else "NEUTRAL")

def analyse_pipeline(df):
    out=df.copy()
    out["rnpv"]=out.apply(lambda r:rnpv(r.success_prob,r.cashflow,
                                        r.years_to_cashflow,r.discount_rate),axis=1)
    out["pipeline_to_market_cap"]=out["rnpv"]/out["market_cap"]
    out["signal"]=out.apply(lambda r:trial_signal(r.enrollment_velocity,
                                                   r.dropout_rate,r.patent_years),axis=1)
    return out

def portfolio_weights(expected_returns, covariance, risk_aversion=3.0):
    mu=np.asarray(expected_returns,float)
    cov=np.asarray(covariance,float)
    inv=np.linalg.pinv(cov)
    raw=inv@mu/risk_aversion
    raw=np.maximum(raw,0)
    return raw/raw.sum() if raw.sum() else np.ones(len(mu))/len(mu)

def sharpe(returns, rf=0.0):
    returns=np.asarray(returns)
    return float((returns.mean()-rf)/(returns.std(ddof=1)+1e-12))
