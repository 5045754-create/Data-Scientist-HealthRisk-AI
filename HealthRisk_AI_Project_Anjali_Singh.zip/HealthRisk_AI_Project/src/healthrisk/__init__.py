"""HealthRisk AI dual-domain analytics package."""
__version__ = "1.0.0"
