from pathlib import Path
from .data import save_demo
from .models import train_risk_models, train_cost_model

def run():
    Path("data/processed").mkdir(parents=True,exist_ok=True)
    patients, hospitals, pharma = save_demo()
    risk_model, risk_metrics = train_risk_models(patients)
    cost_model, cost_metrics = train_cost_model(patients)
    return {
        "rows":len(patients),
        "risk_metrics":risk_metrics,
        "cost_metrics":cost_metrics
    }
