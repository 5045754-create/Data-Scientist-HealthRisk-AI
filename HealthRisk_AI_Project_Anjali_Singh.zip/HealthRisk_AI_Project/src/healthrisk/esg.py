import numpy as np

def esg_score(drug_pricing_exposure, trial_diversity_gap, environmental_intensity,
              governance_flags):
    # Inputs are normalised 0-1 risk indicators; higher score = better.
    risk = (.30*drug_pricing_exposure + .20*trial_diversity_gap +
            .25*environmental_intensity + .25*governance_flags)
    return float(np.clip(100*(1-risk),0,100))

def materiality_band(score):
    if score >= 75: return "Low risk"
    if score >= 50: return "Moderate risk"
    return "High risk"
