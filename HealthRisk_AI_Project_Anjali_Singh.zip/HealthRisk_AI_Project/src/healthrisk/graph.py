"""Graph baseline for comorbidity and drug-interaction networks."""
from collections import defaultdict, deque

def build_cooccurrence_graph(records):
    graph=defaultdict(set)
    for record in records:
        items=list(dict.fromkeys(record))
        for i,a in enumerate(items):
            for b in items[i+1:]:
                graph[a].add(b); graph[b].add(a)
    return {k:sorted(v) for k,v in graph.items()}

def node_degree(graph, node):
    return len(graph.get(node,[]))

def reachable(graph,start):
    seen={start}; q=deque([start])
    while q:
        u=q.popleft()
        for v in graph.get(u,[]):
            if v not in seen:
                seen.add(v); q.append(v)
    return seen
