"""Survival-analysis baseline utilities.

A production build can swap this interface for lifelines/scikit-survival,
DeepSurv or DeepHit while preserving downstream APIs.
"""
import numpy as np

def exponential_survival(time, hazard):
    return float(np.exp(-hazard*max(0,time)))

def c_index(event_time, event_observed, risk):
    event_time=np.asarray(event_time); event_observed=np.asarray(event_observed)
    risk=np.asarray(risk)
    pairs=0; concordant=0
    for i in range(len(event_time)):
        if not event_observed[i]: continue
        for j in range(len(event_time)):
            if event_time[i] < event_time[j]:
                pairs += 1
                if risk[i] > risk[j]: concordant += 1
                elif risk[i] == risk[j]: concordant += .5
    return concordant/pairs if pairs else np.nan
