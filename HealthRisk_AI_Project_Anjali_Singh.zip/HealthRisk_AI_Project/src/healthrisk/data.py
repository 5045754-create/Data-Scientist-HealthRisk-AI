import numpy as np
import pandas as pd

SEED = 42

def make_synthetic_patient_data(n=3000, seed=SEED):
    rng = np.random.default_rng(seed)
    age = rng.integers(18, 91, n)
    chronic = rng.poisson(2.0, n).clip(0, 8)
    hba1c = np.clip(rng.normal(6.9 + 0.12*chronic, 1.1, n), 4.5, 13)
    egfr = np.clip(rng.normal(88 - 5.5*chronic, 18, n), 10, 130)
    admissions = rng.poisson(0.35 + 0.15*chronic, n)
    ed_visits = rng.poisson(0.7 + 0.25*chronic, n)
    medication_count = rng.integers(1, 10, n)
    adherence = np.clip(rng.normal(0.82, 0.12, n), 0.35, 1)
    prior_cost = np.exp(rng.normal(8.6 + .14*chronic + .012*age, .7, n))
    risk_linear = (-4.0 + .025*age + .32*chronic + .20*admissions +
                   .08*ed_visits + .12*(hba1c-7) - .012*(egfr-60) +
                   .18*(1-adherence))
    p_readmit = 1/(1+np.exp(-risk_linear))
    readmit = rng.binomial(1, p_readmit)
    total_cost = prior_cost * (1 + 0.45*readmit + .12*chronic) * rng.lognormal(0, .12, n)
    return pd.DataFrame({
        "age": age, "chronic_conditions": chronic, "hba1c": hba1c,
        "egfr": egfr, "admissions": admissions, "ed_visits": ed_visits,
        "medication_count": medication_count, "adherence": adherence,
        "prior_cost": prior_cost, "readmission_30d": readmit,
        "total_cost": total_cost
    })

def make_hospital_data():
    return pd.DataFrame([
        {"hospital":"H1","revenue_m":450,"operating_margin":.018,"dscr":1.95,
         "cash_days":85,"readmission":.172,"hca_hps":3.0,"cmi_trend":-.09,
         "ed_boarding":8.2,"medicaid_share":.22},
        {"hospital":"H2","revenue_m":600,"operating_margin":.045,"dscr":2.55,
         "cash_days":130,"readmission":.132,"hca_hps":4.0,"cmi_trend":.03,
         "ed_boarding":3.1,"medicaid_share":.14},
        {"hospital":"H3","revenue_m":300,"operating_margin":-.005,"dscr":1.35,
         "cash_days":48,"readmission":.205,"hca_hps":2.0,"cmi_trend":-.12,
         "ed_boarding":10.0,"medicaid_share":.35},
    ])

def make_pharma_pipeline():
    return pd.DataFrame([
        {"company":"AlphaBio","phase":3,"success_prob":.52,"cashflow":8.5e9,
         "years_to_cashflow":3,"market_cap":4.5e9,"discount_rate":.10,
         "enrollment_velocity":1.05,"dropout_rate":.08,"patent_years":11},
        {"company":"BetaThera","phase":2,"success_prob":.31,"cashflow":5.0e9,
         "years_to_cashflow":4,"market_cap":7.0e9,"discount_rate":.11,
         "enrollment_velocity":.91,"dropout_rate":.14,"patent_years":8},
        {"company":"GammaRx","phase":3,"success_prob":.44,"cashflow":3.2e9,
         "years_to_cashflow":2,"market_cap":3.8e9,"discount_rate":.09,
         "enrollment_velocity":1.12,"dropout_rate":.06,"patent_years":4},
    ])

def save_demo():
    p = make_synthetic_patient_data()
    h = make_hospital_data()
    ph = make_pharma_pipeline()
    p.to_csv("data/processed/patients_demo.csv", index=False)
    h.to_csv("data/processed/hospitals_demo.csv", index=False)
    ph.to_csv("data/processed/pharma_demo.csv", index=False)
    return p, h, ph
