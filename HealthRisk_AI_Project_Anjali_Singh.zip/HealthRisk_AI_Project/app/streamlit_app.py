import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import streamlit as st
from src.healthrisk.data import make_synthetic_patient_data, make_hospital_data, make_pharma_pipeline
from src.healthrisk.models import train_risk_models
from src.healthrisk.hospital import probability_default, credit_grade
from src.healthrisk.pharma import analyse_pipeline
from src.healthrisk.epidemiology import sir, r0
from src.healthrisk.simulation import run_simulation

st.set_page_config(page_title="HealthRisk Lab", layout="wide")
st.title("HealthRisk AI — HealthRisk Lab")
st.caption("Educational prototype — not clinical, underwriting, credit or investment advice.")

patients=make_synthetic_patient_data()
model,metrics=train_risk_models(patients)

tab1,tab2,tab3,tab4=st.tabs(["Patient Risk","Hospital Credit","Pharma","Master Simulation"])

with tab1:
    st.subheader("Patient 30-day readmission risk")
    c1,c2,c3=st.columns(3)
    age=c1.slider("Age",18,90,62)
    chronic=c2.slider("Chronic conditions",0,8,3)
    hba1c=c3.slider("HbA1c",4.5,13.0,8.1)
    egfr=st.slider("eGFR",10,130,43)
    row=patients.iloc[0].copy()
    row.update({"age":age,"chronic_conditions":chronic,"hba1c":hba1c,"egfr":egfr})
    p=model.predict_proba(row[model.feature_names_in_].to_frame().T)[:,1][0]
    st.metric("Predicted risk",f"{p:.1%}")
    st.json(metrics)

with tab2:
    st.subheader("Hospital credit early warning")
    h=make_hospital_data()
    st.dataframe(h,use_container_width=True)
    selected=st.selectbox("Hospital",h.hospital)
    r=h[h.hospital==selected].iloc[0]
    pd=probability_default(r.operating_margin,r.dscr,r.cash_days,r.readmission,
                            r.hca_hps,r.cmi_trend,r.ed_boarding)
    st.metric("1-year PD",f"{pd:.1%}",credit_grade(pd))

with tab3:
    st.subheader("Pharmaceutical pipeline analytics")
    p=analyse_pipeline(make_pharma_pipeline())
    st.dataframe(p[["company","phase","rnpv","pipeline_to_market_cap","signal","patent_years"]],use_container_width=True)

with tab4:
    st.subheader("40-quarter Master Mode")
    sim,_,_=run_simulation()
    st.line_chart(sim.set_index("quarter")[["player_capital","ai_capital"]])
    st.metric("Final Player Capital",f"${sim.player_capital.iloc[-1]/1e6:.1f}M")
    st.metric("Final AI Capital",f"${sim.ai_capital.iloc[-1]/1e6:.1f}M")
    st.metric("Score",f"{sim.score.iloc[-1]:.0f}/1000+")
    st.dataframe(sim.tail(10),use_container_width=True)

st.divider()
st.subheader("Epidemiology")
beta=st.slider("Transmission rate β",.05,.80,.35)
gamma=st.slider("Recovery rate γ",.03,.30,.14)
epi=sir(beta,gamma,days=120)
st.line_chart(epi.set_index("day")[["S","I","R"]])
st.write("R₀ =",round(r0(beta,gamma),2))
