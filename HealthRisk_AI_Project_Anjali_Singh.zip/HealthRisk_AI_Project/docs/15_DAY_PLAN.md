# 15-Day Execution Plan

| Day | Work | Output |
|---|---|---|
| 1 | Data acquisition architecture | source map/config |
| 2 | EDA/data quality | profiling + quality report |
| 3 | Clinical features | ICD/lab/comorbidity features |
| 4 | Financial features | insurance/hospital/pharma features |
| 5 | Clinical NLP | ClinicalBERT/NER experiment |
| 6 | GNN | patient-disease-drug graph |
| 7 | Survival | Cox/DeepSurv experiment |
| 8 | XGBoost/LightGBM | tabular baselines |
| 9 | Stacking | meta-learner |
| 10 | Insurance | pricing + IBNR + stratification |
| 11 | Hospital | PD + early warning |
| 12 | Pharma | rNPV + portfolio optimisation |
| 13 | HealthRisk Lab | scenario/game engine |
| 14 | Explainability | SHAP/counterfactuals/model cards |
| 15 | Testing/submission | CI, report, README, private repo |

The supplied MVP implements the core runnable path first; advanced credentialed-data components should be completed only after the required data access and compute environment are available.
