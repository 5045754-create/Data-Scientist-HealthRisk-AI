# HealthRisk Lab Game Design

## Player objective
Maximise risk-adjusted portfolio value while maintaining insurance reserve adequacy, hospital credit quality, pharmaceutical alpha and cross-asset resilience.

## Modes
1. **Actuarial Challenge:** 50,000-member insurance book, 5 years.
2. **Hospital Credit Analyst:** 15-bond portfolio, 10 years.
3. **Pharmaceutical Portfolio Manager:** 20-stock portfolio, 5 years.
4. **Integrated Master Mode:** $500M diversified portfolio, 10 years / 40 quarters.

## Scenario engine
- Pandemic outbreak
- Drug trial failure
- Regulatory approval wave
- Hospital capacity crisis
- Emerging disease
- Reimbursement cut
- Hospital merger
- Safety signal
- Patent cliff
- Normal quarter

## Decision loop
1. Generate health shock.
2. Update clinical/epidemiological signals.
3. Translate signals to financial impacts.
4. Present event to player.
5. Player rebalances.
6. AI opponent rebalances.
7. Apply returns and penalties.
8. Update score and leaderboard.

## Educational outcomes
Learners should demonstrate:
- clinical-to-financial translation
- actuarial reserve thinking
- credit early-warning analysis
- binary pharma event-risk management
- portfolio diversification
- scenario analysis and speed of response

## Certification concept
Bronze: >500 in one mode + Learning Path 1.  
Silver: >650 in two modes + both learning paths.  
Gold: >800 in Master Mode.  
Platinum: top 1% across repeated seasons.
