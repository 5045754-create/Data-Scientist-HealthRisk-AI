# Research and Data Acquisition Notes

The project specification identifies MIMIC-IV, WHO GHO, ClinicalTrials.gov, FDA FAERS, CDC WONDER, HCUP, CMS public-use files, IHME GBD and financial sources such as SEC EDGAR and insurer/hospital data as relevant.

For a student submission:
1. Prefer public, non-identifying datasets.
2. Follow every dataset's terms and access controls.
3. Store only code/configuration in Git.
4. Keep downloaded data in ignored folders.
5. Record dataset version, extraction date and transformation hash.
6. Use temporal validation to avoid leakage.
7. Document synthetic/demo assumptions separately from empirical findings.
