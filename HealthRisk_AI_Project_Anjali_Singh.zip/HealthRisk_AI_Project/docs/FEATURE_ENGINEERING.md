# Feature Engineering Catalogue

| Domain | Feature | Rationale |
|---|---|---|
| Patient | Age | baseline utilisation/risk |
| Patient | Chronic count | comorbidity burden |
| Patient | HbA1c trend | diabetes trajectory |
| Patient | eGFR | renal trajectory |
| Patient | Admissions | utilisation intensity |
| Patient | ED visits | acute instability |
| Patient | Medication count | polypharmacy proxy |
| Patient | Adherence | treatment persistence |
| Insurance | frequency/severity | actuarial pricing |
| Hospital | operating margin | profitability |
| Hospital | DSCR | debt-service capacity |
| Hospital | cash days | liquidity |
| Hospital | readmission | quality/penalty risk |
| Hospital | HCAHPS | patient experience |
| Hospital | CMI trend | acuity/revenue mix |
| Hospital | ED boarding | capacity pressure |
| Pharma | success probability | pipeline risk |
| Pharma | rNPV | valuation |
| Pharma | enrollment velocity | execution signal |
| Pharma | dropout rate | trial risk |
| Pharma | patent runway | revenue cliff |
| ESG | pricing exposure | social materiality |
| ESG | diversity gap | clinical equity |
| ESG | environmental intensity | environmental liability |
| ESG | governance flags | compliance/reputation |
