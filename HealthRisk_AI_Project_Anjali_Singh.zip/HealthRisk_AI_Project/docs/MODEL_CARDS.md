# Model Cards

## Patient Readmission Classifier
**Purpose:** Estimate 30-day readmission risk for educational risk stratification.  
**Model:** Gradient Boosting baseline.  
**Inputs:** demographic, utilisation, laboratory and adherence proxies.  
**Output:** probability 0–1.  
**Metrics:** AUROC, AUPRC, Brier.  
**Limitations:** synthetic demo data; not clinically validated.  
**Fairness:** subgroup analysis required before deployment.

## Hospital PD Model
**Purpose:** Illustrative one-year probability of default.  
**Model:** transparent logistic-style score.  
**Inputs:** operating margin, DSCR, cash days, readmission, HCAHPS, CMI trend, ED boarding.  
**Output:** PD and illustrative grade.  
**Limitations:** coefficients are prototype assumptions.

## Pharma Signal
**Purpose:** Educational pipeline signal.  
**Model:** rule-based feature scoring plus rNPV.  
**Inputs:** success probability, cash flow, time, enrollment, dropout, patent runway.  
**Limitations:** no investment suitability analysis.

## SIR Epidemiology
**Purpose:** Scenario generation.  
**Model:** deterministic compartmental SIR.  
**Limitations:** homogeneous population assumption; not a forecasting system.

## HealthRisk Lab AI Opponent
**Purpose:** Benchmark player decisions in simulation.  
**Model:** shock-aware rebalancing heuristic.  
**Limitations:** not an autonomous financial adviser.
