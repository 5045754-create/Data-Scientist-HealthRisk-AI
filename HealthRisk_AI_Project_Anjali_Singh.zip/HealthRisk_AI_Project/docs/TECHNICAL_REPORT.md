# HealthRisk AI — Technical Report

## 1. Executive Summary

HealthRisk AI is a dual-domain analytical architecture that converts healthcare signals into financial-risk signals. The system is designed around the problem defined in the project brief: clinical outcome prediction, epidemiological modelling, patient risk stratification and pharmaceutical efficacy intelligence are integrated into health insurance, hospital credit, pharmaceutical portfolio and ESG analytics.

The implementation supplied here is an end-to-end prototype. Because credentialed patient-level datasets are not automatically available in this environment, the default pipeline uses synthetic data for reproducibility. Dataset adapters and documentation define how real sources should be integrated after lawful access.

## 2. Problem Statement

Healthcare-financial decisions are often made with separated information. An actuarial model may know claims history but not a patient's changing clinical trajectory. A hospital credit model may know debt service coverage but not deterioration in readmission or patient-experience indicators. A pharma investor may know market price but not systematically score trial-enrolment velocity, dropout or patent runway.

HealthRisk AI closes this gap with a shared feature-fusion layer.

## 3. Objectives

- Build clinical and financial feature pipelines.
- Model patient risk and cost.
- Simulate epidemiological shocks.
- Score hospital default risk.
- Calculate pharma pipeline rNPV and signals.
- Quantify healthcare ESG materiality.
- Integrate signals into a gamified 40-quarter portfolio simulation.
- Provide explainability and governance documentation.

## 4. Data Architecture

### Real-data target sources

MIMIC-IV, WHO GHO, ClinicalTrials.gov, FDA FAERS/openFDA, CDC WONDER, CMS public-use files and SEC EDGAR are target sources.

### Demo data

Synthetic patient, hospital and pharmaceutical records are generated with a fixed seed. This ensures that the evaluator can run the entire project without violating data-use agreements.

## 5. Feature Engineering

Patient features include age, chronic-condition burden, HbA1c, eGFR, admissions, ED visits, medication count, adherence proxy and prior cost. Derived features support readmission and cost prediction.

Hospital features include operating margin, DSCR, days cash, readmission, HCAHPS, CMI trend, ED boarding and Medicaid share.

Pharma features include phase, indication-adjusted success probability, cash flow, time to cash flow, discount rate, enrollment velocity, dropout and patent runway.

## 6. Clinical/Epidemiological Layer

The SIR model is implemented using:
dS/dt = -βSI/N
dI/dt = βSI/N - γI
dR/dt = γI

R0 = β/γ.

The simulation translates outbreak severity into stylised claims and hospital-revenue shocks. These coefficients are explicitly simulation assumptions and must not be interpreted as empirical estimates.

## 7. Patient Risk Model

A Gradient Boosting classifier is used as a reproducible tabular baseline for 30-day readmission. Evaluation includes AUROC, AUPRC and Brier score.

The project brief asks for ClinicalBERT/PubMedBERT, GNN and survival components. The repository therefore treats those as production/research extension points, while the baseline is executable on synthetic data.

## 8. Hospital Credit Model

Expected Loss = PD × LGD × EAD.

PD combines financial health with clinical quality deterioration. A credit-grade mapping translates PD to an illustrative grade.

## 9. Pharmaceutical Analytics

Risk-adjusted NPV is:

rNPV = P(success) × CF / (1+r)^t

For a multi-stage pipeline, each stage can be represented as a separate probability-weighted cash-flow component.

The prototype generates a Positive/Neutral/Negative trial signal using enrollment velocity, dropout and patent runway.

## 10. ESG Analytics

Healthcare ESG is represented by four materiality channels:
- pricing/affordability exposure
- clinical-trial diversity gap
- environmental intensity
- governance flags

The weighted risk score is converted to a 0–100 health-sector ESG score.

## 11. HealthRisk Lab

Master Mode starts with a stylised $500M portfolio and runs 40 quarterly decisions. Scenario types include pandemic outbreak, drug-trial failure, regulatory approval, hospital capacity crisis, emerging disease, reimbursement cut, merger, safety signal, patent cliff and normal conditions.

The AI opponent reduces exposure to the most negatively shocked bucket and reallocates toward the strongest bucket. The player can use the same engine or provide a custom policy.

## 12. Scoring

The reference brief defines a 1000-point framework across insurance management, hospital credit, pharmaceutical alpha, credit-facility management, cross-asset risk and decision quality. The prototype records a continuous simulation score and can be extended to the full category-level rubric.

## 13. Validation

The test suite covers data generation, actuarial utilities, hospital risk, pharma analytics, epidemiology and the integrated simulation. Real clinical performance claims should only be made after evaluation on the actual permitted datasets with temporal holdouts and confidence intervals.

## 14. Explainability

The project includes model-agnostic local contribution and counterfactual helpers. For a production tree model, SHAP should be added when the model is trained on approved real data.

## 15. Risks and Limitations

1. Synthetic data cannot establish clinical validity.
2. Financial shock coefficients are simulation assumptions.
3. No model should be used for automated clinical treatment or underwriting without validation.
4. Historical healthcare data may contain missing-not-at-random patterns and institutional bias.
5. Temporal leakage is a major risk; production evaluation should use time-aware splits.
6. Protected attributes and proxies require fairness analysis before deployment.
7. Investment outputs are educational signals, not recommendations.

## 16. Future Work

- Fine-tune ClinicalBERT on permitted clinical notes.
- Build patient-disease-drug heterogeneous GAT/HGT.
- Add Cox PH and DeepSurv/DeepHit.
- Add MLflow, DVC, Docker and GitHub Actions.
- Connect live public APIs.
- Add full 1000-point gameplay scoring.
- Add calibrated uncertainty and stress testing.
- Add fairness and subgroup calibration dashboards.
