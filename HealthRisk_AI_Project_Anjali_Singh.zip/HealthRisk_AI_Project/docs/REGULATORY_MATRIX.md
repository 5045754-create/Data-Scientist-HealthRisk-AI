# Regulatory / Governance Matrix

| Risk | Control |
|---|---|
| Patient privacy | de-identification, minimum-necessary data, no patient data in Git |
| Model opacity | feature explanations, model cards, audit logs |
| Data leakage | temporal train/test split |
| Clinical harm | human oversight; prototype is non-clinical |
| Insurance fairness | subgroup calibration and actuarial review |
| Credit adverse action | point-in-time explanation and human review |
| Investment misuse | educational-only lab; no automated trade execution |
| API secrets | environment variables and `.env` exclusion |
| Reproducibility | fixed seeds, config files, tests |
| Model drift | monitoring and periodic recalibration |

The project brief specifically emphasises healthcare and financial explainability. Production implementation should be reviewed against applicable jurisdiction-specific requirements before deployment.
