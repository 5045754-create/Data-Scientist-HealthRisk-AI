# Data Dictionary

## Patient
`age`: years  
`chronic_conditions`: count  
`hba1c`: percentage  
`egfr`: mL/min/1.73m²  
`admissions`: previous admissions  
`ed_visits`: emergency visits  
`medication_count`: active medications  
`adherence`: 0–1 proxy  
`prior_cost`: prior-period cost  
`readmission_30d`: target  
`total_cost`: target cost

## Hospital
`revenue_m`: annual revenue in millions  
`operating_margin`: fraction  
`dscr`: debt-service coverage ratio  
`cash_days`: days cash on hand  
`readmission`: 30-day readmission fraction  
`hca_hps`: illustrative star rating  
`cmi_trend`: change in case mix index  
`ed_boarding`: average boarding hours  
`medicaid_share`: payer mix fraction

## Pharma
`phase`: trial phase  
`success_prob`: assumed indication-adjusted success probability  
`cashflow`: projected cash flow  
`years_to_cashflow`: time  
`market_cap`: current market capitalisation  
`discount_rate`: valuation discount rate  
`enrollment_velocity`: actual/target enrollment rate  
`dropout_rate`: trial dropout fraction  
`patent_years`: remaining exclusivity proxy
