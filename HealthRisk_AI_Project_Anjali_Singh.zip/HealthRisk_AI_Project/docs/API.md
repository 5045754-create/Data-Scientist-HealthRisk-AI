# API Overview

```python
from src.healthrisk.epidemiology import sir
from src.healthrisk.insurance import premium
from src.healthrisk.hospital import probability_default
from src.healthrisk.pharma import rnpv
from src.healthrisk.simulation import run_simulation
```

The public functions are documented in their source modules with readable signatures and deterministic demo behaviour.
