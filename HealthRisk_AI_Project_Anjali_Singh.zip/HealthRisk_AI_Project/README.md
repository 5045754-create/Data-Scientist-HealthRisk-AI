# HealthRisk AI — Dual-Domain Healthcare-Financial Intelligence

**Project:** Data Scientist – HealthRisk AI  
**Student:** Anjali Singh  
**Organization brief:** Zetheta Algorithms Private Limited  
**Status:** Runnable academic/prototype implementation  
**Privacy:** Keep the repository private and do not publish proprietary project material.

## 1. Objective

HealthRisk AI combines healthcare intelligence with financial-risk analytics for:

1. Health-insurance actuarial pricing, reserve estimation and member risk stratification.
2. Hospital/healthcare-facility credit risk and early-warning analysis.
3. Pharmaceutical pipeline valuation, clinical-trial signals and portfolio optimisation.
4. Health-sector ESG risk analytics.
5. HealthRisk Lab — a gamified 40-quarter integrated simulation.

The architecture follows the project brief: clinical prediction, epidemiological modelling, patient risk stratification and pharmaceutical efficacy analysis feed financial decision modules.

## 2. Runnable MVP

The project is deliberately runnable without restricted clinical datasets. `src/healthrisk/data.py` creates a deterministic synthetic dataset with the same feature families required by the brief. This is a demonstration layer, not a substitute for credentialed MIMIC-IV or regulated production data.

Run:

```bash
python -m pip install -r requirements.txt
python scripts/run_demo.py
streamlit run app/streamlit_app.py
pytest -q
```

The demo creates:
- insurance risk predictions
- hospital PD / credit score
- pharma rNPV and signal
- ESG score
- SIR epidemiology forecast
- 40-quarter HealthRisk Lab simulation
- CSV/JSON outputs under `data/processed/`

## 3. Architecture

```text
MIMIC-IV / WHO / ClinicalTrials.gov / FAERS / CDC / CMS / SEC
                         |
                         v
                Data Quality Layer
                         |
          +--------------+--------------+
          |              |              |
      Clinical NLP     Clinical       Financial
      / Text            Graphs        Features
          |              |              |
          +-------+------+--------------+
                  v
          Model Feature Fusion
       +----------+----------+
       |          |          |
   XGBoost      Survival    Risk Signals
   baseline      models
       |          |          |
       +----------+----------+
                  v
          Ridge/ElasticNet
           meta-learner
                  |
       +----------+-----------+-----------+
       |          |           |           |
   Insurance   Hospital    Pharma       ESG
     Risk       Credit    Portfolio     Analytics
       |          |           |           |
       +----------+-----------+-----------+
                  v
             HealthRisk Lab
          40-quarter simulator
                  |
          Player vs AI opponent
```

## 4. Data strategy

### Demo mode
Synthetic records are used to validate the end-to-end engineering path.

### Research mode
Adapters should be populated from:
- MIMIC-IV / PhysioNet
- WHO Global Health Observatory
- ClinicalTrials.gov
- FDA FAERS/openFDA
- CDC WONDER
- CMS public-use files
- SEC EDGAR

Restricted datasets must only be used after their access agreements are satisfied. Never commit patient-level data, credentials or API keys.

## 5. Core modules

- `epidemiology.py`: SIR model and outbreak financial shock.
- `insurance.py`: premium, risk score, MLR and IBNR utilities.
- `hospital.py`: clinical-financial PD score and expected loss.
- `pharma.py`: rNPV, trial signal and portfolio optimisation.
- `esg.py`: healthcare ESG materiality score.
- `models.py`: baseline ensemble and evaluation metrics.
- `simulation.py`: 40-quarter scenario engine and AI opponent.
- `explainability.py`: model-agnostic feature contributions/counterfactual helper.
- `data.py`: synthetic demo data and validation.

## 6. Model governance

This prototype is decision-support software, not a clinical diagnostic system, insurance filing model, credit approval system or investment recommendation engine. Production deployment requires domain validation, legal/regulatory review, privacy controls, bias testing, calibration, monitoring and human oversight.

## 7. Project deliverables

See:
- `docs/TECHNICAL_REPORT.md`
- `docs/MODEL_CARDS.md`
- `docs/GAME_DESIGN.md`
- `docs/FEATURE_ENGINEERING.md`
- `docs/REGULATORY_MATRIX.md`
- `docs/DATA_DICTIONARY.md`
- `docs/15_DAY_PLAN.md`

## 8. Reproducibility

All demo randomness uses a fixed seed. Model artifacts and raw data are intentionally excluded from Git. Configure real data paths through environment variables or YAML.

## 9. License / IP

This repository is prepared for the private Zetheta project context. Do not publish it publicly. Any transfer or ownership instruction must follow the project supervisor's instructions.
